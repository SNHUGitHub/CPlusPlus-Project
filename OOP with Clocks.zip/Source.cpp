// Declare libraries that are used in this program
#include <iostream>
#include <string>
#include <iomanip>

using namespace std;

// Define function to display clocks
void displayClocks(int& displayHours, int& displayMinutes, int& displaySeconds) {

	// Declare and/or initialize variables
	string amPM;
	int secondsConverter = 0;
	int minutesConverter = 0;
	int display12Hours = displayHours; // Variable to display 12-hour format

	// Define condition to print valid seconds format
	if ((displaySeconds >= 0) && (displaySeconds <= 60)) {

		// Define condition to print valid minutes format
		if ((displayMinutes >= 0) && (displayMinutes <= 60)) {

			// Define condition to print valid hours format
			if ((displayHours >= 0) && (displayHours <= 24)) {

				// Define condition to convert second '60' to second '00'
				if (displaySeconds == 60) {

					// Convert second
					displaySeconds = secondsConverter;

					// Add a minute when user adds a second from second '59'
					displayMinutes += 1;
				}

				// Define condition to convert minute '60' to minute '00'
				if (displayMinutes == 60) {

					// Convert minute
					displayMinutes = minutesConverter;

					// Add an hour when user adds a minute from minute '59'
					displayHours += 1;
					display12Hours += 1;

					// Add a second when user adds a minute from minute '59'
					if (displaySeconds == 59) {
						displaySeconds += 1;
						displaySeconds = secondsConverter; // Convert second to correct format
					}
				}																																							

				// Define condition to print "PM"
				if ((displayHours >= 12) && (displayHours <= 23)) {

					// Define condition and loop to convert from 24-hour to 12-hour format
					if ((displayHours >= 13) && (displayHours <= 23)) {

						// Declare and/or initialize variables for loop
						int i;
						int tempVal = displayHours;
						int hourConverter = 0;

						for (i = 13; i <= tempVal; ++i) {
							hourConverter += 1;
							display12Hours = hourConverter;
						} 
					}

					// Remaining conditions to print "PM"
					if ((displayMinutes >= 0) && (displayMinutes <= 59)) {
						if ((displaySeconds >= 0) && (displaySeconds <= 59)) {
							amPM = "PM";
						}
					}
				}

				// Define condition to print "AM"
				else {
					amPM = "AM";
				}

				// Define condition to convert hour '24' into hour '00'
				if (displayHours == 24 || displayHours == 0) {

					// Declare and initialize variables
					int midnightConverter24 = 0;
					int midnightConverter12 = 12;

					displayHours = midnightConverter24; // Convert 24-hour clock 
					display12Hours = midnightConverter12; // Convert 12-hour clock
				}
				
				// Print clocks side-by-side with extra '0' in front of numbers 0-9 using setw(2) and setfill('0')
				cout << "**************************     **************************" << endl;
				cout << "*     12-Hour Clock      *     *      24-Hour Clock     *" << endl;
				cout << "*" << "      " << setw(2) << setfill('0') << display12Hours << ":";
				cout << setw(2) << setfill('0') << displayMinutes << ":";
				cout << setw(2) << setfill('0') << displaySeconds << " " << amPM << "       *     *        ";
				cout << setw(2) << setfill('0') << displayHours << ":";
				cout << setw(2) << setfill('0') << displayMinutes << ":";
				cout << setw(2) << setfill('0') << displaySeconds << "        *" << endl;
				cout << "**************************     **************************" << endl;
			}
		}
	}
}

// Define function to print user menu
void userMenu() {
	cout << "Please enter a number from the menu below: \n";
	cout << "**************************" << endl;
	cout << "* 1 - Add One Hour       *" << endl;
	cout << "* 2 - Add One Minute     *" << endl;
	cout << "* 3 - Add One Second     *" << endl;
	cout << "* 4 - Exit Program       *" << endl;
	cout << "**************************" << endl;
}

// Define function to display user menu
void displayMenu(int viewHours, int viewMinutes, int viewSeconds) {

	// Declare variable
	int userNumSelection;

	// Add new line
	cout << endl;

	// Call userMenu function
	userMenu();

	// Input user selection
	cin >> userNumSelection;
	
	// Define loop for program to run until user exits program
	while (!(userNumSelection == 4)) {

		// Define loop to allow users to continue adding hours, minutes, or seconds in no specific order
		while ((userNumSelection >= 1) && (userNumSelection <= 3)) {

			// Condition to add an hour if user selects #1
			if (userNumSelection == 1) {
				viewHours += 1;
				system("cls"); // Clear screen
				displayClocks(viewHours, viewMinutes, viewSeconds);
				cout << endl;
				userMenu();
				cin >> userNumSelection;
			}

			// Condition to add a minute if user selects #2
			if (userNumSelection == 2) {
				viewMinutes += 1;
				system("cls"); // Clear screen
				displayClocks(viewHours, viewMinutes, viewSeconds);
				cout << endl;
				userMenu();
				cin >> userNumSelection;
			}

			// Condition to add a second if user selects #3
			if (userNumSelection == 3) {
				viewSeconds += 1;
				system("cls"); // Clear screen
				displayClocks(viewHours, viewMinutes, viewSeconds);
				cout << endl;
				userMenu();
				cin >> userNumSelection;
			}
		}

		// Define loop to ensure user only enters options displayed on user menu
		while (!((userNumSelection >= 1) && (userNumSelection <= 4))) {
			system("cls"); // Clear screen
			displayClocks(viewHours, viewMinutes, viewSeconds);
			cout << endl;
			cout << "Invalid selection. ";
			userMenu();
			cin >> userNumSelection;
		}
	}

	// Condition to exit program if user selects #4
	if (userNumSelection == 4) {
		cout << "Goodbye." << endl;
	}
}

// Define main()
int main() {
	// Declare and/or initialize variables
	int timeHours = 15;
	int timeMinutes = 22;
	int timeSeconds = 01;

	// Call function to display clocks
	displayClocks(timeHours, timeMinutes, timeSeconds);

	// Call function to display user menu;
	displayMenu(timeHours, timeMinutes, timeSeconds);

	return 0;
}